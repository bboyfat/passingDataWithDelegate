//
//  Company.swift
//  TaskFiveContactsBase
//
//  Created by Andrey Petrovskiy on 3/19/19.
//  Copyright © 2019 Andrey Petrovskiy. All rights reserved.
//

import Foundation


struct Contact{
    
    let name: String
    let phoneNumber: Int
    
    let city: String
    let adress: String
}
